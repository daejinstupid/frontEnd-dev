import React, { useEffect, useState } from "react";
import "./Manager.css";
import Footer from "../Footer";
import ManagerNav from "./ManagerNav";

const Manager = () => {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoaded(true);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div>
      <ManagerNav />
      <div className={`manager_index_text ${isLoaded ? "show" : ""}`}>
        <h1>cafe-in</h1>
        <p>
          저희 cafe-in 플랫폼은 카페 직원들이 고객뿐만 아니라 스터디와 협업을 원하는 분들에게 최적의 매칭 서비스를 제공하도록 돕습니다.
        </p>
        <p>
          직원들은 효율적인 예약 시스템을 통해 판매를 최적화하고 테이블 회전율을 높일 수 있으며, 이는 매출 증가로 이어집니다.
        </p>
        <p>
          커피와 학습, 네트워킹이 어우러진 공간을 관리하는 카페인의 직원이 되어, 혁신적인 카페 운영 경험을 직접 체험해 보세요. 이제 카페는 단순한 휴식 공간을 넘어 다양한 가능성을 제공합니다.
        </p>
      </div>
      <div className="advantages_section">
        <h2>cafe-in을 선택해야 하는 4가지 이유</h2>
      </div>
      <div className="manager_index_img">
        <div className="image-container">
          <img src="assets/iStock-1493148325.jpg" alt="매장관리" />
          <div className="overlay-text">
            cafe-in은 관리자들이 매장의 예약 현황과 판매 데이터를 직관적으로 파악할 수 있도록 돕습니다. 
            강력한 관리 도구를 통해 실시간으로 매장을 효율적으로 운영할 수 있으며, 손쉽게 매장의 성과를 모니터링할 수 있습니다.
          </div>
          <div className="caption">매장관리</div>
        </div>
        <div className="image-container">
          <img src="assets/1004213.jpg" alt="이미지 2" />
          <div className="overlay-text">
            cafe-in은 고객의 예약 요청을 빠르고 정확하게 처리하여, 매장의 자원을 최적으로 활용할 수 있게 합니다. 
            고객이 원하는 시간에 빈 자리를 예약할 수 있도록 지원하며, 이를 통해 자원의 낭비를 최소화하고 효율성을 극대화합니다.
          </div>
          <div className="caption">효율적인 제공</div>
        </div>
        <div className="image-container">
          <img src="assets/iStock-1411488704.jpg" alt="이미지 3" />
          <div className="overlay-text">
            cafe-in의 예약 시스템은 고객의 방문을 체계적으로 관리하여, 테이블 회전율을 높이고 대기 시간을 줄입니다. 
            이로 인해 고객 만족도가 향상되고, 더 많은 고객이 반복 방문하게 됩니다.
          </div>
          <div className="caption">고객 순환</div>
        </div>
        <div className="image-container">
          <img src="assets/iStock-1726419055.jpg" alt="이미지 4" />
          <div className="overlay-text">
            cafe-in을 통해 매장의 매출
          </div>
          <div className="caption">매출 증대</div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Manager;
